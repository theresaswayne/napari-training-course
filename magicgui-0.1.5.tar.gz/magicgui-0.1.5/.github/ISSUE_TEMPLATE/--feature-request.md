---
name: "\U0001F680Feature Request"
about: Submit a proposal/request for a new magicgui feature
title: ''
labels: ''
assignees: ''

---
