---
name: "❓Question/Help/Support"
about: Just need some help.
title: ''
labels: ''
assignees: ''

---

## ❓ Questions and Help

<!-- Please note that this issue tracker is not a help form and this issue will be closed. -->

[ ] I have searched the [documentation](https://magicgui.readthedocs.io/)
