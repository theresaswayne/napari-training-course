"""Unit test package for magicgui."""
